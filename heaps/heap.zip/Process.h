#ifndef PROCESS_H
#define PROCESS_H
#include <iostream>
#include<vector>
#include<string>
using namespace std;

class Process
{
private:
    int arrival;
    int time;
    string tasks;
    string prioiety;
public:
    Process();
};

#endif // PROCESS_H
